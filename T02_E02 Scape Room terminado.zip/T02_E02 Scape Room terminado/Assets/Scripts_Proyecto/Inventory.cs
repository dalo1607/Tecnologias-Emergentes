﻿using UnityEngine;
using System.Collections;
/*CLASE INVENTARIO*/
public class Inventory : MonoBehaviour {

	//Variable booleana ,para saber si lleva la llave o no.
	public bool Llave = false;
}
